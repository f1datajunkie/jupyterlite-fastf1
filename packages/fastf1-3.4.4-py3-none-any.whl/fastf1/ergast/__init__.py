# imports for exposed names
from fastf1.ergast.interface import Ergast  # noqa: F401
from fastf1.ergast.legacy import fetch_results  # noqa: F401
from fastf1.ergast.legacy import (  # noqa: F401
    fetch_day,
    fetch_season
)
