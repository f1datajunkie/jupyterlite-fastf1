# python-signalr-client

This module is based on the excellent work of Stanislav Lazarov. 
Since the original module is no longer developed it's been integrated
into Fast-F1. Original source https://github.com/slazarov/python-signalr-client

